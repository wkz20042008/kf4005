#include <stdio.h>
main()
{
    char i;
    for(i='A' ; i<='Z' ; ++i)
        putchar(i);
}
