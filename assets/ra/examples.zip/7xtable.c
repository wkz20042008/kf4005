#include <stdio.h>

main()
{
  int a;
  for(a=1 ; a<=10 ; ++a)
    printf("%2i x 7 = %2i\n",  a, a*7);
}
