#include <stdio.h>

main()
{
  int n;
  scanf("%d", &n);
  printf(">%d\n",n);
  scanf("%2d\n", &n);
  printf(">%d\n",n);
  scanf("%4d\n", &n);
  printf(">%d\n",n);
  scanf("%6d\n", &n);
  printf(">%d\n",n);
}
