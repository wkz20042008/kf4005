int max(int a, int b);  /* declaration of max */
