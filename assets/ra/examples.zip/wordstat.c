#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <errno.h>

int main( int argc, char **argv)
{
     enum {WORDBUFERSIZE=80};
     char word[WORDBUFERSIZE];
     FILE *data;
     int words=0, maxlen=0;

     if(argc<2) exit(EXIT_FAILURE);

     if (!(data = fopen(argv[1],"r")) ) {
       perror("wordstat can't open a file");
       exit(EXIT_FAILURE);
     }

     while( fscanf(data,"%s",word)!=EOF )
     {
          if (strlen(word)>maxlen) maxlen=strlen(word);
          ++words;
     }
     printf("%d words, max length %d characters\n",words, maxlen);

     fclose(data);
}
