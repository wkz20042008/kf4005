#include <stdio.h>
#include <strings.h>
main()
{
    enum{SIZE=80};
    char word[SIZE];
    int longest=0,wc=0;
    while(scanf("%s",word)!=EOF)
         if(strlen(word)>longest) longest=strlen(word);
    printf("longest word is %i characters\n",longest);
}
