#include <stdio.h>

main()
{
  char firstname[20];
  char secondname[20];
  char fullname[30];
  int len;
  scanf("%s",firstname);
  scanf("%s",secondname);
  strcpy (fullname,firstname);
  len = strlen(firstname);
  strncat(fullname,secondname,30-len-1); /* Length of fullname: 
                                            less the number of characters in
                                            firstname, less 1 for the
                                            terminating null character
                                         */ 
  printf(fullname);
}
