#include <stdio.h>
#include <string.h>
main()
{
    enum { BUFSIZE = 1000, INPUTSIZE = 100 };
    const char *SEP = " ";
    char s[BUFSIZE];
    char cs[INPUTSIZE];
    *s = '\0';
    while (scanf("%s",cs)!=EOF && strlen(s) < (BUFSIZE - INPUTSIZE)) {
        strcat(s, SEP);
	strcat(s, cs);
    }
    printf("%s",s);
}
