#include <stdio.h>
main()
{
    int a;
    char b;
    int c[10];
    char d[10];
    printf("i %i\n", sizeof(int) );
    printf("c %i\n", sizeof(char) );
    printf("a %i\n", sizeof a );
    printf("b %i\n", sizeof b );
    printf("c %i\n", sizeof c );
    printf("d %i\n", sizeof d );
}
