#include <stdio.h>
main()
{
    char *p;
    p = "hello, world";
    while (*p) {       /* equivalent to while(*p!=0) */
        putchar(*p);
        ++p;
    }
}
