#include <stdio.h>
main()
{
     char a[100],b[100];
     scanf("%s:%s",a,b);
     printf("'%s'%s'\n",a,b);
}
