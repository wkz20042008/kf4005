#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <strings.h>

int main( int argc, char **argv )
{
    enum {BUFSIZE=132};
    char line[BUFSIZE];
    FILE *data;
    int d, total=0;
    
    if (argc<2) exit(EXIT_FAILURE); /* no filename given,
                                        return a failure exit code*/
    data = fopen(argv[1],"r");
    if( data == NULL ) {
      perror("sum cannot open a file");
      exit(EXIT_FAILURE);
    }
  
    while( fgets(line, BUFSIZE, data) )
    {
         sscanf(line,"%i",&d);
         total+=d;
    }
    fclose(data);
    
    /* a more compact file open */
    if( !(data=fopen(argv[1],"a")) ) {
      perror("Can't open file for appending");
      exit(EXIT_FAILURE);
    }
    fprintf(data,"--------\n%8d\n",total);
    fclose(data);
}
