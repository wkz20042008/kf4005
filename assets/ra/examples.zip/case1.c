#include <stdio.h>
main()
{
    char c;
    c = getchar();
    while (c != EOF ) {
	if ('A' <= c && c <= 'Z')
	    c = c + 32;
        putchar(c);
	c = getchar();
    }
}
