#include <stdio.h>
#include "libmax.h"

int main ( int argc , char *argv[] )
{
     int p = 5;
     int q = 8;
     printf("%i\n", max(p,q) );
}
