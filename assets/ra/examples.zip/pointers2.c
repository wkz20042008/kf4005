#include <stdio.h>
main()
{
    char *p;
    int *w;
    p = "ABCDEFGHIJZLMNOPQRSTUVW";
    w = (int*)p;
    while( *w ){
        putchar(*w);
        ++w;
    }
}
