#include <stdio.h>

main()
{
     int a = 5;
     int b = 2;
     int c;
     int *p;    /* a pointer to an int */
     printf("a = %i, b = %i, c = %i\n",a,b,c);

     p = &a;    /* p points to a */
     c = *p;    /* c now equals a */
     *p = b;    /* a now equals b */

     printf("a = %i, b = %i, c = %i\n",a,b,c);
}
