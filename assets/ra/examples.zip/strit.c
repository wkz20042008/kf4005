#include <stdio.h>
main()
{
    enum { BUFSIZE = 100 };
    char buf[BUFSIZE];
    int i;

    fgets(buf, BUFSIZE, stdin);
    buf[strlen(buf)-1]='\0';/*delete the newline character*/
    for (i = 0; buf[i]; ++i)
	if (islower(buf[i]))
	    printf("%c is lower case\n", buf[i]);
	else if (isupper(buf[i]))
	    printf("%c is upper case\n", buf[i]);
	else
	    printf("'%c' is neither\n", buf[i]);
}
