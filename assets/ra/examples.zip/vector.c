#include <stdio.h>

int main(int argc , char **argv)
{
    int i;
    int a[3],b[3];

    for(i=0 ; i<3 ; ++i)
    {
        scanf("%i", &a[i]);
    }

    printf("[%i,%i,%i]\n",a[0],a[1],a[2]);
}

