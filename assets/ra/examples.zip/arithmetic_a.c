#include <stdio.h>

int main(int argc, char **argv)
{
  int a,b;
  a = atoi(argv[1]);
  b = atoi(argv[2]);

  printf("%i + %i = %i\n", a, b, a+b);
  printf("%i - %i = %i\n", a, b, a-b);
  printf("%i * %i = %i\n", a, b, a*b);
  printf("%i / %i = %i\n", a, b, a/b);
  printf("%i %% %i = %i\n", a, b, a%b);
}
