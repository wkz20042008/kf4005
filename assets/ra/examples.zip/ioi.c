#include <stdio.h>
main()
{
  int a,b;
  while(scanf(" %d %d",&a,&b)!=EOF)
    printf("/%d=%d\n",b,a);
}
