#include <stdio.h>
int main()
{
  int n=5;
  printf("|%d|\n",n);
  printf("|%5d|\n",n);
  printf("|%05d|\n",n);
  printf("|%-5d|\n",n);

  float p= 1.0/6.0;
  printf("|%f|\n",p);
  printf("|%6f|\n",p);
  printf("|%6.2f|\n",p);
  printf("|%-6.2f|\n",p);
}
