#include <stdio.h>

main()
{
  char *sample = "This is a bit of sample text!";

  printf("|%s|\n",sample);
  printf("|%10s|\n",sample);
  printf("|%40s|\n",sample);
  printf("|%-40s|\n",sample);
  printf("|%20.10s|\n",sample);
  printf("|%.10s|\n",sample);
}
