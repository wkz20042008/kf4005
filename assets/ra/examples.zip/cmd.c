#include <stdio.h>
/*
  A program to print out the arguments to main.
  It illustrates how the command line input is
  split into words, and assigned to the argc and
  argv parameters to main.
*/
int main (int argc, char *argv[])
{
    int i;
    for (i = 0; i <= argc; ++i)
        printf ("argument %i=%s\n", i, argv[i]);
}
