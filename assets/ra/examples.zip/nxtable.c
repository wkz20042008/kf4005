#include <stdio.h>

main()
{
  int n,a;
  do
  {
    printf("type a number:");
    scanf("%d", &a);
  }
  while( a<1 || a>10 );
  for(n=1 ; n<=10 ; ++n)
    printf("%2i x %2i = %2i\n", n, a, n*a);
}
