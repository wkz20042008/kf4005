#include <stdio.h>

main()
{
  int a,b;
  printf("type an integer:");
  scanf("%i",&a);
  printf("type an integer:");
  scanf("%i",&b);

  printf("%i + %i = %i\n", a, b, a+b);
  printf("%i - %i = %i\n", a, b, a-b);
  printf("%i * %i = %i\n", a, b, a*b);
  printf("%i / %i = %i\n", a, b, a/b);
  printf("%i %% %i = %i\n", a, b, a%b);
}
