#include <stdio.h>

main()
{
     const int LISTSIZE = 10;
     int squares[LISTSIZE];
     int i;
     for( i=0 ; i<LISTSIZE ; ++i)
          squares[i] = i*i;

     for( i=LISTSIZE-1 ; i>=0 ; --i )
          printf("%2d squared is %3d\n",i,squares[i]);
}
