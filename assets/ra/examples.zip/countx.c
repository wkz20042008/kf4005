#include <stdio.h>
main()
{
    enum {BUFSIZ=100};
    char a[BUFSIZ];
    char *p;
    int count = 0;

    fgets(a, BUFSIZ, stdin);

    p=a;
    while( *p ) {
        if (*p=='x') 
            ++count;
        ++p;
    }
    printf("%i\n",count);
}
