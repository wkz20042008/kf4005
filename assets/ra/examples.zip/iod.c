#include <stdio.h>
main()
{
  int a;
  for(a=0;a<6;++a)
    printf("%5d %5d\n",a,a*a);
}
