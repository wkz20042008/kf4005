#include <stdio.h>

int max(int a, int b);  /* declaration of max */

main()
{
     int p = 5;
     int q = 8;
     printf("%i\n", max(p,q) );
}

int max(int a, int b)   /* definition of max */
{
     return (a>=b)?a:b;
}
