#include <stdio.h>
enum { BUFFERSIZE = 132; } /* makes a constant integer */
char buffer[BUFFERSIZE];   /* buffer to read lines into */

main()
{
     while( fgets(buffer, BUFFERSIZE, stdin) )
     {
          /* process line here... */
     }
}
