#include <stdio.h>

main()
{
  float a,b;
  printf("type a float:");
  scanf("%f",&a);
  printf("type a float:");
  scanf("%f",&b);

  printf("%f + %f = %f\n", a, b, a+b);
  printf("%f - %f = %f\n", a, b, a-b);
  printf("%f * %f = %f\n", a, b, a*b);
  printf("%f / %f = %f\n", a, b, a/b);
}
