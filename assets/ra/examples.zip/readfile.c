#include <stdio.h>          /* read and process input line-by-line */

const int LINEBUFFER = 80;  /* define a length of a line buffer    */
char line[LINEBUFER];       /* declare a buffer to read lines into */

main()
{
    while( fgets(stdin, LINEBUFFER, line) )
    {
         /* process line */
    }
}
