#include <stdio.h>
main()
{
    int n,a,b;
    int ans,score=0;
    for(n=1 ; n<=10 ; ++n)
    {
         a = random()%10;
         b = random()%10;
         printf("question %2i: %i * %i ?",n,a,b);
         scanf("%i",&ans);
         if( ans == (a*b) )
         {
             ++score;
             printf("correct\n");

         }else{
              printf("sorry, the right answer is %i\n",a*b);
         }
    }
    printf("your score is %i\n",score);
}
