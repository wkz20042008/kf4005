#include <stdio.h>
#include <ctype.h>
main()
{
    char c;
    while ((c=getchar()) != EOF) {
	if (isupper(c))
	    c = toupper(c);
        putchar(c);
    }
}
