int max(int a, int b)   /* definition of max */
{
     return (a>=b)?a:b;
}
